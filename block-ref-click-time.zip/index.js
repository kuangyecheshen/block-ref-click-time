const { Plugin } = require("siyuan");

module.exports = class BlockRefClickTimePlugin extends Plugin {
    async onload() {
        console.log("[BlockRefClickTime] ===== 插件开始加载 =====");

        this.boundElements = new Set();
        this.observer = null;
        this.lastInputTime = 0;
        this.lastEnterTime = 0;

        // 加载持久化存储
        this.clickedRefs = new Map();
        try {
            const saved = await this.loadData("clickedRefs.json");
            if (saved && typeof saved === "object") {
                for (const [key, value] of Object.entries(saved)) {
                    this.clickedRefs.set(key, value);
                }
                console.log(`[BlockRefClickTime] 已加载 ${this.clickedRefs.size} 条历史记录`);
            } else {
                console.log("[BlockRefClickTime] 暂无历史记录");
            }
        } catch (err) {
            console.log("[BlockRefClickTime] 加载历史记录失败（首次使用属正常）:", err);
        }

        // 输入事件监听（input / keydown / keyup 三个都监听）
        this.inputHandler = () => { this.lastInputTime = Date.now(); };
        document.addEventListener("input", this.inputHandler, true);
        document.addEventListener("keydown", this.inputHandler, true);
        document.addEventListener("keyup", this.inputHandler, true);

        // 专门监听回车键
        this.enterHandler = (e) => {
            if (e.key === "Enter" || e.keyCode === 13 || e.which === 13) {
                this.lastEnterTime = Date.now();
            }
        };
        document.addEventListener("keydown", this.enterHandler, true);
        document.addEventListener("keyup", this.enterHandler, true);

        // 点击监听
        this.globalClickHandler = this.handleGlobalClick.bind(this);
        document.addEventListener("click", this.globalClickHandler, true);

        this.setupGlobalObserver();

        // 只在插件启动时恢复一次（延迟 1 秒等页面加载完）
        setTimeout(() => this.restoreAllTags(), 1000);

        console.log("[BlockRefClickTime] ===== 插件加载完成 =====");
    }

    async onunload() {
        if (this.globalClickHandler) {
            document.removeEventListener("click", this.globalClickHandler, true);
            this.globalClickHandler = null;
        }
        if (this.inputHandler) {
            document.removeEventListener("input", this.inputHandler, true);
            document.removeEventListener("keydown", this.inputHandler, true);
            document.removeEventListener("keyup", this.inputHandler, true);
            this.inputHandler = null;
        }
        if (this.enterHandler) {
            document.removeEventListener("keydown", this.enterHandler, true);
            document.removeEventListener("keyup", this.enterHandler, true);
            this.enterHandler = null;
        }
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        this.boundElements.clear();
        console.log("[BlockRefClickTime] 插件已卸载");
    }

    async saveClickedRefs() {
        try {
            const obj = {};
            for (const [key, value] of this.clickedRefs.entries()) {
                obj[key] = value;
            }
            await this.saveData("clickedRefs.json", obj);
        } catch (err) {
            console.error("[BlockRefClickTime] 保存数据失败:", err);
        }
    }

    // 启动时恢复所有标签（只在插件启动时调用一次，不做定时扫描）
    restoreAllTags() {
        const refs = document.querySelectorAll(
            '[data-type="block-ref"], [data-type~="block-ref"]'
        );
        refs.forEach((ref) => {
            this.bindBlockRef(ref);
            const refId = this.getRefIdentifier(ref);
            if (refId && this.clickedRefs.has(refId)) {
                const timeString = this.clickedRefs.get(refId);
                const existingTag = ref.nextElementSibling;
                if (!(existingTag && existingTag.classList.contains("block-ref-time-tag"))) {
                    this.updateTimeTag(ref, timeString, refId);
                }
            }
        });
        console.log(`[BlockRefClickTime] 启动时扫描了 ${refs.length} 个块引用`);
    }

    setupGlobalObserver() {
        const targetNode = document.body;
        const config = { childList: true, subtree: true };

        this.observer = new MutationObserver((mutationsList) => {
            for (const mutation of mutationsList) {
                if (mutation.type !== "childList") continue;

                mutation.addedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) return;

                    if (this.isBlockRef(node)) {
                        this.bindBlockRef(node);
                        this.tryRestoreTag(node);
                    }

                    if (node.querySelectorAll) {
                        const refs = node.querySelectorAll(
                            '[data-type="block-ref"], [data-type~="block-ref"]'
                        );
                        refs.forEach((ref) => {
                            this.bindBlockRef(ref);
                            this.tryRestoreTag(ref);
                        });
                    }
                });
            }
        });

        this.observer.observe(targetNode, config);
    }

    // 带守卫的恢复：编辑期间和编辑后 3 秒内不恢复
    tryRestoreTag(refElement) {
        // 输入后 3 秒内不恢复
        if (Date.now() - this.lastInputTime < 3000) return;
        // 回车后 3 秒内不恢复
        if (Date.now() - this.lastEnterTime < 3000) return;

        const refId = this.getRefIdentifier(refElement);
        if (!refId) return;
        if (!this.clickedRefs.has(refId)) return;

        const timeString = this.clickedRefs.get(refId);
        const existingTag = refElement.nextElementSibling;
        if (existingTag && existingTag.classList.contains("block-ref-time-tag")) {
            if (existingTag.getAttribute("data-time") !== timeString) {
                existingTag.textContent = ` [点击于: ${timeString}]`;
                existingTag.setAttribute("data-time", timeString);
            }
            return;
        }
        this.updateTimeTag(refElement, timeString, refId);
    }

    isBlockRef(el) {
        if (!el || !el.getAttribute) return false;
        const dataType = el.getAttribute("data-type") || "";
        return dataType === "block-ref" || dataType.includes("block-ref");
    }

    bindBlockRef(el) {
        if (this.boundElements.has(el)) return;
        el.addEventListener("click", (e) => this.handleBlockRefClick(e, el), true);
        this.boundElements.add(el);
    }

    // 只检查点击目标本身是否是块引用，不再向上看父级
    handleGlobalClick(event) {
        // 输入后 800ms 内忽略点击
        if (Date.now() - this.lastInputTime < 800) return;
        // 回车后 500ms 内忽略点击
        if (Date.now() - this.lastEnterTime < 500) return;

        const target = event.target;
        if (this.isBlockRef(target)) {
            this.handleBlockRefClick(event, target);
        }
    }

    getRefIdentifier(refElement) {
        const parentBlock = refElement.closest('[data-node-id]');
        if (!parentBlock) return null;

        const parentId = parentBlock.getAttribute('data-node-id');

        const allRefs = parentBlock.querySelectorAll(
            '[data-type="block-ref"], [data-type~="block-ref"]'
        );
        let index = -1;
        for (let i = 0; i < allRefs.length; i++) {
            if (allRefs[i] === refElement) {
                index = i;
                break;
            }
        }
        if (index === -1) return null;

        const refId = refElement.getAttribute("data-id")
            || refElement.getAttribute("data-ref-id")
            || "";

        return `${parentId}::${refId}::${index}`;
    }

    handleBlockRefClick(event, refElement) {
        if (!refElement) return;

        // 回车后 500ms 内禁止更新时间
        if (Date.now() - this.lastEnterTime < 500) return;

        const refId = this.getRefIdentifier(refElement);
        if (!refId) return;

        const now = Date.now();
        if (refElement._lastClickTime && now - refElement._lastClickTime < 500) {
            return;
        }
        refElement._lastClickTime = now;

        const timeString = this.formatTime(new Date());
        console.log(`[BlockRefClickTime] 块引用被点击! ID: ${refId}, 时间: ${timeString}`);

        this.clickedRefs.set(refId, timeString);
        this.saveClickedRefs();
        this.updateTimeTag(refElement, timeString, refId);
    }

    formatTime(date) {
        const pad = (n) => String(n).padStart(2, "0");
        const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
        const weekday = weekdays[date.getDay()];
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} 星期${weekday} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    }

    updateTimeTag(refElement, timeString, refBlockId) {
        const TAG_CLASS = "block-ref-time-tag";
        let existingTag = refElement.nextElementSibling;

        if (!existingTag || !existingTag.classList.contains(TAG_CLASS)) {
            existingTag = null;
        }

        if (existingTag) {
            existingTag.textContent = ` [点击于: ${timeString}]`;
            existingTag.setAttribute("data-time", timeString);
        } else {
            const timeTag = document.createElement("span");
            timeTag.className = TAG_CLASS;
            timeTag.setAttribute("data-ref-id", refBlockId);
            timeTag.setAttribute("data-time", timeString);
            timeTag.textContent = ` [点击于: ${timeString}]`;
            timeTag.style.cssText = [
                "color: #888;",
                "font-size: 0.8em;",
                "margin-left: 4px;",
                "user-select: none;",
                "pointer-events: none;",
            ].join(" ");

            try {
                refElement.insertAdjacentElement("afterend", timeTag);
                console.log(`[BlockRefClickTime] 时间标签已插入: ${timeString}`);
            } catch (err) {
                console.error("[BlockRefClickTime] 插入时间标签失败:", err);
            }
        }
    }
};