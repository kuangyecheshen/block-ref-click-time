const { Plugin } = require("siyuan");

module.exports = class BlockRefClickTimePlugin extends Plugin {
    async onload() {
        console.log("[BlockRefClickTime] ===== 插件开始加载 =====");

        this.boundElements = new Set();
        this.observer = null;
        // 用于存储“被点击过的块引用”及其时间信息
        // Key: 块引用元素的唯一标识
        // Value: 时间字符串
        this.clickedRefs = new Map();

        // 全局点击监听（捕获阶段）
        this.globalClickHandler = this.handleGlobalClick.bind(this);
        document.addEventListener("click", this.globalClickHandler, true);

        // 核心修正：使用 MutationObserver 监听 DOM 变化，
        // 不仅用于发现新的块引用，也用于在块被重新渲染后
        // 恢复我们插入的时间标签。
        this.setupGlobalObserver();

        console.log("[BlockRefClickTime] ===== 插件加载完成 =====");
    }

    async onunload() {
        if (this.globalClickHandler) {
            document.removeEventListener("click", this.globalClickHandler, true);
            this.globalClickHandler = null;
        }
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        this.boundElements.clear();
        this.clickedRefs.clear();
        console.log("[BlockRefClickTime] 插件已卸载");
    }

    setupGlobalObserver() {
        const targetNode = document.body;
        const config = { childList: true, subtree: true };

        this.observer = new MutationObserver((mutationsList) => {
            for (const mutation of mutationsList) {
                if (mutation.type !== "childList") continue;

                // 1. 检查新增节点中是否包含块引用，并为其绑定点击
                mutation.addedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) return;

                    if (this.isBlockRef(node)) {
                        this.bindBlockRef(node);
                        // 关键：如果这个块引用之前被点击过，立刻恢复其时间标签
                        this.restoreTimeTag(node);
                    }

                    if (node.querySelectorAll) {
                        const refs = node.querySelectorAll(
                            '[data-type="block-ref"], [data-type~="block-ref"]'
                        );
                        refs.forEach((ref) => {
                            this.bindBlockRef(ref);
                            this.restoreTimeTag(ref);
                        });
                    }
                });

                // 2. 检查被移除的节点，如果包含我们添加的时间标签，
                // 理论上不需要特别处理，因为 clickedRefs 中仍然保留着记录。
                // 当块引用重新出现时，会触发上面的 addedNodes 逻辑。
            }
        });

        this.observer.observe(targetNode, config);
    }

    isBlockRef(el) {
        if (!el || !el.getAttribute) return false;
        const dataType = el.getAttribute("data-type") || "";
        return dataType === "block-ref" || dataType.includes("block-ref");
    }

    bindBlockRef(el) {
        if (this.boundElements.has(el)) return;
        el.addEventListener("click", (e) => this.handleBlockRefClick(e, el), true);
        this.boundElements.add(el);
    }

    handleGlobalClick(event) {
        let target = event.target;
        let refElement = null;
        for (let i = 0; i < 10 && target; i++) {
            if (this.isBlockRef(target)) {
                refElement = target;
                break;
            }
            target = target.parentElement;
        }
        if (refElement) {
            this.handleBlockRefClick(event, refElement);
        }
    }

    // 获取块引用元素的唯一标识，用于在重新渲染后识别它
    getRefIdentifier(refElement) {
        // 优先使用 data-node-id，它是思源中块的标准唯一标识
        return refElement.getAttribute("data-node-id") 
            || refElement.getAttribute("data-id")
            || refElement.getAttribute("data-ref-id")
            || refElement.textContent.trim(); // 最后的兜底方案
    }

    handleBlockRefClick(event, refElement) {
        if (!refElement) return;

        const refId = this.getRefIdentifier(refElement);
        const now = Date.now();
        // 防止对同一个元素的同一次点击重复处理
        if (refElement._lastClickTime && now - refElement._lastClickTime < 500) {
            return;
        }
        refElement._lastClickTime = now;

        const timeString = this.formatTime(new Date());
        console.log(`[BlockRefClickTime] 块引用被点击! ID: ${refId}, 时间: ${timeString}`);

        // 核心：将点击记录保存起来
        this.clickedRefs.set(refId, timeString);

        // 插入时间标签
        this.updateTimeTag(refElement, timeString, refId);
    }

    // 恢复时间标签的方法
    restoreTimeTag(refElement) {
        const refId = this.getRefIdentifier(refElement);
        // 检查这个块引用是否被点击过
        if (this.clickedRefs.has(refId)) {
            const timeString = this.clickedRefs.get(refId);
            // 检查当前是否已经存在时间标签（避免重复插入）
            const existingTag = refElement.nextElementSibling;
            if (existingTag && existingTag.classList.contains("block-ref-time-tag")) {
                return; // 已存在，无需恢复
            }
            this.updateTimeTag(refElement, timeString, refId);
            console.log(`[BlockRefClickTime] 时间标签已恢复: ${timeString}`);
        }
    }

    // 修改后的 formatTime，加入了星期几
    formatTime(date) {
        const pad = (n) => String(n).padStart(2, "0");
        const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
        const weekday = weekdays[date.getDay()];
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} 星期${weekday} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    }

    updateTimeTag(refElement, timeString, refBlockId) {
        const TAG_CLASS = "block-ref-time-tag";
        // 先尝试通过紧邻兄弟元素查找
        let existingTag = refElement.nextElementSibling;

        if (!existingTag || !existingTag.classList.contains(TAG_CLASS)) {
            // 如果紧邻的兄弟元素不是我们的标签，再通过父元素查找
            const parent = refElement.parentElement;
            if (parent) {
                existingTag = parent.querySelector(`.${TAG_CLASS}[data-ref-id="${refBlockId}"]`);
            } else {
                existingTag = null;
            }
        }

        if (existingTag && existingTag.classList.contains(TAG_CLASS)) {
            existingTag.textContent = ` [点击于: ${timeString}]`;
            existingTag.setAttribute("data-time", timeString);
        } else {
            const timeTag = document.createElement("span");
            timeTag.className = TAG_CLASS;
            timeTag.setAttribute("data-ref-id", refBlockId);
            timeTag.setAttribute("data-time", timeString);
            timeTag.textContent = ` [点击于: ${timeString}]`;
            timeTag.style.cssText = [
                "color: #888;",
                "font-size: 0.8em;",
                "margin-left: 4px;",
                "user-select: none;",
                "pointer-events: none;",
            ].join(" ");

            try {
                refElement.insertAdjacentElement("afterend", timeTag);
                console.log(`[BlockRefClickTime] 时间标签已插入: ${timeString}`);
            } catch (err) {
                console.error("[BlockRefClickTime] 插入时间标签失败:", err);
            }
        }
    }
};